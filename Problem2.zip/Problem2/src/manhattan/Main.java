package manhattan;
import java.util.ArrayList; 
//all the codes is made by myself
public class Main {
	public static void main(String[] args) {
		

		int cost = 0;
		
		ArrayList<State> openlist = new ArrayList<State>();
		ArrayList<State> closelist = new ArrayList<State>();         //
		ArrayList<State> children = new ArrayList<State>();
		State start = new State(0, 1, 2, 6, 4, 8, 7, 5, 3,null, 0);
		openlist.add(start);
		
		State location = null;
		//State node = null;
		while (!openlist.isEmpty()) {
			
			State node = openlist.get(0);
			int length = openlist.size();
			
			//find the node which have shortest f in the openlist.
			int smallest = 0;
			
			for(int i=0; i<length; i++) {
				if(openlist.get(i).f < node.f) { 
					node = openlist.get(i);
					smallest = i;
				}
				
			}
			
			
			openlist.remove(smallest);
			closelist.add(node);                 //
			cost++;
			
			System.out.println("f = "+node.f);
			
			//check if the node is goal
			if(node.isgoal()) {
				location = node;
				break;
			}
			
			//add the children to the oplist
			children = node.Succcessor();
			for(int i=0; i<children.size(); i++) {       //
				for(int n=0; n<closelist.size(); n++) {
					if (children.get(i).same(closelist.get(n).tiles)) {
						children.remove(i);
						//System.out.println("renode");
						i--;
						break;
					}
				}
			}
			openlist.addAll(children);
			
			
		}
		
		//get the path.
		ArrayList<State> path = new ArrayList<State>();
		
		if (location==null) {
			System.out.println("there is no solution.");
		}
		else {
			
			State f = location;
			do {
				path.add(f);
				f = f.parent;
				
			}while(f!=null) ;
		}
		
		for (int i = path.size()-1; i>=0; i--){
			System.out.println(path.get(i).tiles[0][0]+" "+path.get(i).tiles[0][1]+" "+path.get(i).tiles[0][2]+" "+path.get(i).tiles[1][0]+" "+path.get(i).tiles[1][1]+" "+path.get(i).tiles[1][2]+" "+path.get(i).tiles[2][0]+" "+path.get(i).tiles[2][1]+" "+path.get(i).tiles[2][2]);
		}
		//System.out.println(cost); Pref.
		System.out.println("the Manhattan distance");
		System.out.println("the cost of the path is " + (path.size()-1));
		System.out.println("the cost mrasured by #nodes generated is " + (openlist.size()+cost));
	}
	
	
} 
