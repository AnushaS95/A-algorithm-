package anytimeastar;

public class anytimeastar {

}
