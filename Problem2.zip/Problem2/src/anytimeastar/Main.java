package anytimeastar;

import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		
		
		
		int cost = 0;
		
		int lcost = 2000000;
		ArrayList<State> closelist = new ArrayList<State>();   
		ArrayList<State> openlist = new ArrayList<State>();
		
		ArrayList<State> children = new ArrayList<State>();
		State start = new State(7, 2, 4, 5, 0, 6, 8, 3, 1, null, 0);
		openlist.add(start);
		
		State location = null;
		while(!openlist.isEmpty() && ((cost+openlist.size())<lcost)) {
			System.out.println("recearch start & befor cost: "+(cost+openlist.size()));
			while (!openlist.isEmpty() && ((cost+openlist.size())<lcost)) {
				
				State node = openlist.get(0);
				int length = openlist.size();
				
				int smallest = 0;
				for(int i=0; i<length; i++) {
					if(openlist.get(i).fA(0.6) < node.fA(0.6)) { 
						node = openlist.get(i);
						smallest = i;
					}
					
				}
				
				
				cost++;
				openlist.remove(smallest);
				closelist.add(node);                         
				
				if(node.isgoal()) {
					if(location==null) location = node;
					else if(location.f > node.f) {
						location = node;	
					}
					System.out.println("find a solution, cost= " + location.f);
					for (int i=0; i<openlist.size(); i++) {
						if(openlist.get(i).f >= location.f) {
							closelist.add(openlist.get(i));       
							openlist.remove(i);
							i--;
							cost++;
						}
					}
					break;	
				}
				
			
				children = node.Succcessor();
				for(int i=0; i<children.size(); i++) {      
					for(int n=0; n<closelist.size(); n++) {
						if (children.get(i).same(closelist.get(n).tiles)) {
							if(children.get(i).f>=closelist.get(n).f) {		
								children.remove(i);
						
								i--;
								break;
							}
							
						}
					}
				}
				openlist.addAll(children);
				
				
				
			}
		}

		
		//get the path.
		ArrayList<State> path = new ArrayList<State>();
		
		if (location==null) {
			System.out.println("there is no solution.");
		}
		else {
			
			State f = location;
			do {
				path.add(f);
				f = f.parent;
				
			}while(f!=null) ;
		}
		
		for (int i = path.size()-1; i>=0; i--){
			System.out.println(path.get(i).tiles[0][0]+" "+path.get(i).tiles[0][1]+" "+path.get(i).tiles[0][2]+" "+path.get(i).tiles[1][0]+" "+path.get(i).tiles[1][1]+" "+path.get(i).tiles[1][2]+" "+path.get(i).tiles[2][0]+" "+path.get(i).tiles[2][1]+" "+path.get(i).tiles[2][2]);
		}
		System.out.println("Anytime A* of  Manhattan distance");
		System.out.println("the cost of the path is " + (path.size()-1));
		System.out.println("the time upper limit of the cost ) = "+ lcost);
		System.out.println("the cost measured by nodes generated is " + (openlist.size()+cost));
	}
	
	
}

