package anytimeastar;

public class stateanytime {

}
