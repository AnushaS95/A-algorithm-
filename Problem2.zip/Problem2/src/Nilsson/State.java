package Nilsson;

import java.util.ArrayList;

public class State {
	
	static int cost;
	int[][] tiles = new int[3][3];
	int g;
	int h;
	int f;
	State parent;

	public State(int a, int b, int c, int d, int e, int f, int g, int h, int i, State s, int z) {
	
	this.tiles[0][0] = a;
	this.tiles[0][1] = b;
	this.tiles[0][2] = c;
	this.tiles[1][0] = d;
	this.tiles[1][1] = e;
	this.tiles[1][2] = f;
	this.tiles[2][0] = g;
	this.tiles[2][1] = h;
	this.tiles[2][2] = i;
	
	
	this.parent = s;
	this.g = z;
	this.h = this.Nilsson();
	this.f = this.g + this.h;
	
	}
	
	public State(int[][] tiles, State s) {
		this.tiles = tiles;
		this.g = s.g+1;
		
		this.parent = s;
		
		this.h = this.Nilsson();
		this.f = this.g + this.h;
	}
	
	public State(int[][] tiles) {
		this.tiles = tiles;
		this.parent = null;
		this.g = 0;
		this.h = 0;
		this.f = 0;
	}


	public ArrayList<State> Succcessor() {
		
	
		ArrayList<State> successor = new ArrayList<State> ();
		
		if(getRow(this.tiles, 0)>0) {  
			int[][] T = new int[3][3];
			
			
			for(int i = 0; i<3; i++)
				for(int n = 0; n<3; n++) {
					T[i][n] = this.tiles[i][n];
				}
					
			T[getRow(this.tiles, 0)][getCol(this.tiles, 0)] = T[getRow(this.tiles,0)-1][getCol(this.tiles,0)];
			T[getRow(this.tiles, 0)-1][getCol(this.tiles, 0)] = 0;
			
			if (this.parent==null || T!=this.parent.tiles) {
			State s=new State(T, this);
			successor.add(s);
			}
		}
		
	
		if(getRow(this.tiles, 0)<2) {
			int[][] T = new int[3][3];
			
			
			for(int i = 0; i<3; i++)
				for(int n = 0; n<3; n++) {
					T[i][n] = this.tiles[i][n];
				}
					
			T[getRow(this.tiles, 0)][getCol(this.tiles, 0)] = T[getRow(this.tiles,0)+1][getCol(this.tiles,0)];
			T[getRow(this.tiles, 0)+1][getCol(this.tiles, 0)] = 0;
			
			if (this.parent==null || T!=this.parent.tiles) {
			State s=new State(T, this);
			successor.add(s);
			}
		}
	
		if(getCol(this.tiles, 0)>0) {
			int[][] T = new int[3][3];
			
			
			for(int i = 0; i<3; i++)
				for(int n = 0; n<3; n++) {
					T[i][n] = this.tiles[i][n];
				}
					
			T[getRow(this.tiles, 0)][getCol(this.tiles, 0)] = T[getRow(this.tiles,0)][getCol(this.tiles,0)-1];
			T[getRow(this.tiles, 0)][getCol(this.tiles,0)-1] = 0;
			
			if (this.parent==null || T!=this.parent.tiles) {
			State s=new State(T, this);
			successor.add(s);
			}
		}
	
		if(getCol(this.tiles, 0)<2) {
			int[][] T = new int[3][3];
			
			
			for(int i = 0; i<3; i++)
				for(int n = 0; n<3; n++) {
					T[i][n] = this.tiles[i][n];
				}
					
			T[getRow(this.tiles, 0)][getCol(this.tiles, 0)] = T[getRow(this.tiles,0)][getCol(this.tiles,0)+1];
			T[getRow(this.tiles, 0)][getCol(this.tiles,0)+1] = 0;

			if (this.parent==null || T!=this.parent.tiles) {
			State s=new State(T, this);
			successor.add(s);
			}
		}
		return successor;
	}
	
	
	public boolean same(int[][] a) {
		
		for(int n = 0; n<3; n++) 
			for(int i = 0; i<3; i++) {
				if(this.tiles[n][i] != a[n][i]) {
					return false;
					
				}
				
			}
		return true;
		
	}
	
	
	public boolean isgoal() {
		
		for(int n = 0; n<3; n++) 
			for(int i = 0; i<3; i++) {
				if(this.tiles[n][i] != getFinalState().tiles[n][i]) {
					return false;
					
				}
				
			}
		return true;
		
	}
	

	public State getFinalState() {
		int[][] finalArray = new int[3][3];
        int value = 0;

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                
                if ((col == 0) && (row == 0)) {
                    finalArray[row][col] = 0;
                } else {
                    finalArray[row][col] = value;
                }
                value++;

            }
        }
        State finalState = new State (finalArray);

        return finalState;
		
	}
	
	
	
	
	public int getCol(int[][] a, int value) {
		int c = -1;
		for (int row = 0; row <3; row++) {
            for (int col = 0; col < 3; col++) {
                if (a[row][col] == value) {
                    
                    return col;
                    
                }
            }
        }
	return c;
        
		
	}
	

	public int getRow(int[][] a, int value) {
		int r = -1;
		for (int row = 0; row < a.length; row++) {
            for (int col = 0; col < a[row].length; col++) {
                if (a[row][col] == value) {
                    return row;
                }
            }
        }
       
		return r;
	}
	
	
	int Manhattan() {
		int count = 0;
        int expected = 0;

        for (int row = 0; row < tiles.length; row++) {

            for (int col = 0; col < tiles[row].length; col++) {

                int value = tiles[row][col];
                

                if (value != 0 && value != expected) {
                	
                    count += Math.abs(row - getRow(getFinalState().tiles, value))
                            + Math.abs(col - getCol(getFinalState().tiles, value));
                }
                
                expected++;
            }
		}
        
        return count;
	}
	
	public boolean ncheck(int a, int b) {
		int m[] = {1, 2, 5, 8, 7, 6, 3, 0};
		int n = 0;
		for (int i = 0; i<7; i++) {
			if(m[i]==a) {
				n = i;
				break;
			}
		}
		if(m[n+1]==b) 
			return true;
		else 
			return false;
		
	}
	
	
	int S() {
		int sn = 0;
		int[][] T = this.tiles;
		int f = -1;
		int b = -1;
		//1
		f = T[0][0];
		b = T[0][1];
		if (f!=0) {
			if( !ncheck(f, b) )
				sn = sn + 2;
		}
		//2
		f = T[0][1];
		b = T[0][2];
		if (f!=0) {
			if( !ncheck(f, b) )
				sn = sn + 2;
		}
		//3
		f = T[0][2];
		b = T[1][2];
		if (f!=0) {
			if( !ncheck(f, b) )
				sn = sn + 2;
		}
		//4
		f = T[1][2];
		b = T[2][2];
		if (f!=0) {
			if( !ncheck(f, b) )
				sn = sn + 2;
		}
		//5
		f = T[2][2];
		b = T[2][1];
		if (f!=0) {
			if( !ncheck(f, b) )
				sn = sn + 2;
		}
		//6
		f = T[2][1];
		b = T[2][0];
		if (f!=0) {
			if( !ncheck(f, b) )
				sn = sn + 2;
		}
		//7
		f = T[2][0];
		b = T[1][0];
		if (f!=0) {
			if( !ncheck(f, b) )
				sn = sn + 2;
		}
		//8
		f = T[1][0];
		b = T[0][0];
		if (f!=0) {
			if( !ncheck(f, b) )
				sn = sn + 2;
		}
		
		if(T[1][1]!=0 & T[1][1]!=4)
			sn++;
		
		return sn;
		
	}
	
	int Nilsson() {
		int n = this.Manhattan() + 3 * this.S();
		return n;
	}
}



